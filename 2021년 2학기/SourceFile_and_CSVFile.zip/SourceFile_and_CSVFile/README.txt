README

1) [No_PCA]다중회귀분석: Original Data로 다중회귀분석 진행, Stepwise 진행
2) [PCA]다중회귀분석: PCA 변수 7개로 다중회귀분석
3) make_police9, make_police10, make_police12, make_total: 데이터 전처리 과정
4) Neural_Net: 딥러닝 모델링
5) 앙상블_모델: 앙상블 모델링
6) 결과제출: 결과제출 만드는 코드
7) submit3: 결과제출
8) correct_answer.csv: 앙상블 모델로 만든 정답
9) q3.csv, q5.csv: 다중회귀분석으로 만든 정답
10) total.csv: 2017 ~ 2020년 데이터 정리
11) PCA.csv: PCA 데이터
12) Basic.csv: 경찰서명, year, 상반기로 구분된 데이터
