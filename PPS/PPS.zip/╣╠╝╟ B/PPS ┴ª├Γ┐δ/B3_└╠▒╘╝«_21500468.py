{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 8,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "baekjoon\n",
      "<baekjoon> is acceptable.\n",
      "end\n"
     ]
    }
   ],
   "source": [
    "while(1):\n",
    "    password = input()\n",
    "    if password == \"end\":\n",
    "        break\n",
    "    vowel = ['a','e','i','o','u']\n",
    "    vowel_check = False\n",
    "    vowel_cnt = 0\n",
    "    three_check = False\n",
    "    double_check = False\n",
    "\n",
    "    before_letter = \"\"\n",
    "    for letter in password:\n",
    "        if (before_letter in vowel and letter not in vowel) or (before_letter not in vowel and letter in vowel):\n",
    "            vowel_cnt = 0\n",
    "\n",
    "        if letter in vowel:\n",
    "            vowel_check = True\n",
    "            vowel_cnt +=1      #모음이 연속\n",
    "        if not letter in vowel:\n",
    "            vowel_cnt -=1     #자음이 연속을 모음이 3번 안오는 것으로 표현\n",
    "        if letter != 'e' and letter != 'o':\n",
    "            if before_letter == letter:\n",
    "                double_check = True\n",
    "                break\n",
    "        if vowel_cnt >=3 or vowel_cnt <= -3:\n",
    "            three_check = True\n",
    "            break\n",
    "        before_letter = letter\n",
    "\n",
    "    if vowel_check == False or three_check == True or double_check == True:\n",
    "        print(\"<{0}> is not acceptable.\".format(password))\n",
    "    else:\n",
    "        print(\"<{0}> is acceptable.\".format(password))\n",
    "\n",
    "#깨달은 점\n",
    "'''\n",
    "   if letter != 'e' and letter != 'o': \n",
    "조건에 있어서, e도 아니고 o도 아니여야 하므로 and를 사용해야 한다.\n",
    "이 부분이 살짝 헷갈리지만 점점 알아가는 중.\n",
    "다른 한 가지는 if not letter == 'e' or letter == 'o' 를 했는데, 이때\n",
    "not은 앞에 조건인 letter != 'e'로만 적용되지 뒤의 조건은 담아내지 못한다.\n",
    "\n",
    "'''\n",
    "\n",
    "    "
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.7.6"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 4
}
