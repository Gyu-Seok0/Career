{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 41,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "1 100\n",
      "10\n",
      "0 0\n"
     ]
    }
   ],
   "source": [
    "while(1):\n",
    "    a,b = map(int,input().split())\n",
    "    if a==0 and b==0:\n",
    "        break\n",
    "    check = [1]\n",
    "    cnt = 0\n",
    "    \n",
    "    for i in range(1,b+1):\n",
    "        if i==1:\n",
    "            check.append(1)\n",
    "        elif i>=2:\n",
    "            temp = check[i-1] + check[i-2]\n",
    "            if temp > b:\n",
    "                break\n",
    "            else:\n",
    "                check.append(temp)\n",
    "        if check[i] >= a:\n",
    "            cnt+=1\n",
    "    print(cnt)\n",
    "    \n"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.7.6"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 4
}
